* Enhance demo page to show all sorts of edge cases, like when bugs were
  found.  shidec has IE7 fixes with uniformed 'a' elements, which might
  be needed if they are still broken.
* Add tests.  szaboat added Jasmine tests.  May wish to be more thorough?
  Not browser based?
* IE8 issue when file button was moved to the left side?  See
  https://github.com/kamilogorek/uniform/commit/d71e77f997e033e69fe0070f06428f8318cd9324
* See if selects of various heights work in webkit
  https://github.com/AdrianGyuricska/uniform/commit/1fca129d7de2e5812f172f6f7b96a9df7c55a063
